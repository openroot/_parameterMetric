# parametermetric
 Web program pronounce as 'ParameterMetric' try to provide a play-mate eco syetem.

### Information and best design practices
1. The basic version of codes are arranged inside directory '<webroot or htdocs or www>/lid/home/well'.
2. On executing file 'index.php', it will automatically initiate project structure.
3. Custom initiation coding (e.g., project parameters exchanges), seeks manual coding after lifetime-first run.
4. It's a portable project for custom coding and future-ready. Lifetime-first run it do not consists any generic enviornment based ethics (e.g., installation script etc.).
5. Project structure recognized as in "Tree", 'directories' are recognized as 'nodes' as in "Leaves of Tree" and 'files' as 'vertices' as in "Flowers & Fruits of Tree" as 'Computer Programming Ethics' as in "Plants".
6. Coding files and of any custom structure of directories best placed on 'leaf nodes'. When it's mentioned as ethics to provide readability of programming, it do not have any impact over structure integrity.